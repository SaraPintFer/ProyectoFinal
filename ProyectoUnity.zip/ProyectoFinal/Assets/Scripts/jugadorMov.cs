using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class jugadorMov : MonoBehaviour
{
    private Vector2 move;
    public float speed;
    public Rigidbody2D rb2d;
    public Animator jugador;

    public int direccion;

    public TextMeshProUGUI textoVida;
    public int vidaJugador;
    public TextMeshProUGUI textoCordura;
    public int corduraJugador;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        vidaJugador=5;
        corduraJugador=5;
    }

    // Update is called once per frame
    void Update()
    {
        if(vidaJugador>0 && corduraJugador>0){

            //Movimiento (flechas o letras)

            
        }
    }
}
