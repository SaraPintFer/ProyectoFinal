using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class botonResalte : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Zonas datoZona;
    public GameObject resaltado;
    public GameObject zonaAsociada;

    public EventosManager eventosManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {  
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void OnPointerEnter(PointerEventData eventData){
        GameObject jugador = GameObject.FindGameObjectWithTag("Player");
        if (zonaAsociada.GetComponent<Collider2D>().OverlapPoint(jugador.transform.position)){
            resaltado.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData){
        resaltado.SetActive(false);
    }

    public void MostrarVentana(){
        GameObject jugador = GameObject.FindGameObjectWithTag("Player");
        if (zonaAsociada.GetComponent<Collider2D>().OverlapPoint(jugador.transform.position)){
            if(this.gameObject.CompareTag("Puerta")){
                eventosManager.MostrarPista(datoZona.textoPuerta, datoZona.idZona+10);
            }else   eventosManager.MostrarPista(datoZona.textoPista, datoZona.idZona);
        }
    }
}
