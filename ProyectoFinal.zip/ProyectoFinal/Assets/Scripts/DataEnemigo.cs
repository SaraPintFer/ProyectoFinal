using UnityEngine;

[CreateAssetMenu(fileName = "NewEnemigo", menuName = "Enemigo")]
public class DataEnemigo : ScriptableObject
{
    public Sprite imagen;
    public int vida;
    public int ataque;
}
