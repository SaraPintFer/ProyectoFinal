using UnityEngine;

public class PersonajeActual
{
    public int vida;
    public int cordura;
    public int fuerza;
    public int agilidad;
    public int conocimiento;
    public int observacion;

    public PersonajeActual(Personajes baseData){

        vida = baseData.vida;
        cordura = baseData.cordura;
        fuerza = baseData.fuerza;
        agilidad = baseData.agilidad;
        conocimiento = baseData.conocimiento;
        observacion = baseData.observacion;
    }
}