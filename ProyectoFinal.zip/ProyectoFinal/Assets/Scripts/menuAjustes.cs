using UnityEngine;
using UnityEngine.UI;

public class menuAjustes : MonoBehaviour
{
    public Toggle ToggleMusica;
    public Scrollbar SliderVolumen;
    public float volumen;
    private float untimoVol;

    [SerializeField] private GameObject Panel;
    public Scrollbar SliderBrillo;
    public float brillo;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        SliderVolumen.value = PlayerPrefs.GetFloat("volumen", 0.5f);
        untimoVol = volumen;
        AudioListener.volume = SliderVolumen.value;

        SliderBrillo.value = PlayerPrefs.GetFloat("brillo", 0.9f);
        Image panelImage = Panel.GetComponent<Image>();
        Color c = panelImage.color;
        c.a = 1f - SliderBrillo.value;
        panelImage.color = c;

        ToggleMusica.onValueChanged.AddListener(OnToggleChanged);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void cambioSliderVol(float valor){
        volumen = valor;
        if (!ToggleMusica.isOn && volumen > 0f){
            ToggleMusica.isOn = true;
            return;
        }
        if (ToggleMusica.isOn){
            AudioListener.volume= volumen;
        }

        PlayerPrefs.SetFloat("volumen", volumen);
    }

    public void cambioSliderBri(float valor){
        brillo = valor > 0.1f ? valor : 0.1f;
        PlayerPrefs.SetFloat("brillo", brillo);
        Image panelImage = Panel.GetComponent<Image>();
        Color c = panelImage.color;
        c.a = 1f - brillo;
        panelImage.color = c;
    }

    public void OnToggleChanged(bool isOn)
    {
        if (isOn){
            AudioListener.volume = untimoVol;
            SliderVolumen.value = untimoVol;
        }
        else{
            untimoVol = SliderVolumen.value;
            SliderVolumen.value = 0f;
            AudioListener.volume = 0f;
        }
    }
}
