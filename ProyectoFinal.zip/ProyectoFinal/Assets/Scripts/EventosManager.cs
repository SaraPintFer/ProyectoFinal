using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro;

public class EventosManager : MonoBehaviour
{
    [SerializeField] private GameObject buttonPista;
    [SerializeField] private GameObject buttonPista2;
    [SerializeField] private GameObject buttonPista3;
    [SerializeField] private GameObject buttonPista4;
    [SerializeField] private GameObject buttonPista5;
    [SerializeField] private GameObject buttonPista6;
    [SerializeField] private GameObject buttonPuerta;
    
    [SerializeField] private GameObject panelTexto;
    [SerializeField] private TextMeshProUGUI textoPista;
    [SerializeField] private GameObject botonAceptar;

    [SerializeField] private GameObject panelIntro;
    [SerializeField] private TextMeshProUGUI textoIntro;
    [SerializeField] private Animator fundido;

    [SerializeField] private GameObject transicion;
    [SerializeField] private Animator fundidoMapa;

    public bool llaveMansion = false;
    public bool pistaFuente = false;
    public bool pistaEstatuas = false;
    public bool pistaEstatuas2 = false;
    public bool pistaPuerta = false;
    public bool pistaDiario = false;
    public bool pistaPapel = false;
    public bool pistaCocina = false;
    public bool pistaLibro = false;
    private bool activarDialogo = false;
    
    private int pistaActiva;
    public gestionIU gestionIU;
    private GameManager gameManager;
    public SonidoManager sonidoManager;

    [SerializeField] public GameObject enemigo;
    [SerializeField] public GameObject enemigo2;
    [SerializeField] private GameObject enemigo3;
    [SerializeField] private GameObject boss;

    public int cont=0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemigo2.SetActive(false);
        boss.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {  
    }

    public void MostrarNarrativa(string texto)
    {
        StartCoroutine(fundidoTexto(texto));
    }
    private IEnumerator fundidoTexto(string texto){
        panelIntro.SetActive(true);
        fundido.SetTrigger("fundidoText");
        textoIntro.text = texto;
        yield return new WaitForSeconds(4f);
        panelIntro.SetActive(false);
    }

    public void MostrarPista(string texto, int idZona)
    {
        panelTexto.SetActive(true);
        textoPista.text = texto;
        pistaActiva = idZona;
    }

    public void Aceptar(){
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        jugadorMov mover = player.GetComponent<jugadorMov>();
        int index= gestionIU.index;
        var personaje = GameManager.instance.personajeActual;
        switch (pistaActiva)
        {
            case 11:
                if (llaveMansion){
                    panelTexto.SetActive(false);
                    sonidoManager.cambiarAudio(3);
                    //transportar hasta mapa mansión
                    StartCoroutine(TransicionMapa());
                    enemigo2.SetActive(true);
                    enemigo.transform.position = new Vector3(-29.5f, 0f, 0f);
                    enemigo2.transform.position = new Vector3(-28f, 2f, 0f);
                    player.transform.position = new Vector3(-28f, -5f, 0f);
                    mover.MoverHacia(new Vector3(-28f, -2f, 0f));
                    Camera.main.transform.position = new Vector3(-26f, 0f, -10f);
                    gestionIU.activarDialogo(2);
                }else{
                    textoPista.text = "Necesitas recoger 'Llave Mansión'";
                    botonAceptar.SetActive(false);
                } 
                break;
            case 2:
                if(!pistaEstatuas){
                    pistaEstatuas = true;
                    //Necesita tirada de Observación
                    int tirada = Random.Range(1, 21);
                    int resultado = personaje.observacion + tirada;
                    if(resultado>14){
                        textoPista.text = "-Tirada Válida-\nEncuentras una poción enmohecida.\n¿Deseas tomarla?\n(Tirada de Conocimiento)";
                    }else{
                        botonAceptar.SetActive(false);
                        buttonPista2.SetActive(false);
                        pistaEstatuas2 = true;
                        textoPista.text = "-Tirada Fallida-\nAl inspeccionar las estatuas te haces un corte.\n(-2 vida)";
                        personaje.vida -= 2;
                    }
                }else{
                    buttonPista2.SetActive(false);
                    pistaEstatuas2 = true;
                    botonAceptar.SetActive(false);
                    int tirada = Random.Range(1, 21);
                    int resultado = personaje.conocimiento + tirada;
                    if(resultado>14){
                        textoPista.text = "-Tirada Válida-\nReconoces el líquido y decides beberlo.\n(+1 Vida  +1 Cordura)";
                        personaje.vida += 1;
                        personaje.cordura += 1;
                    }else{
                        textoPista.text = "-Tirada Fallida-\nBebes el extraño líquido y te mareas un poco.\n(-2 Vida  -1 Cordura)";
                        personaje.vida -= 2;
                        personaje.cordura -= 1;
                    }
                }                
                //Actualizar la UI
                gestionIU.ActualizarValores();               
                break;
            case 13:
                panelTexto.SetActive(false);
                //Transportar hasta mapa biblioteca
                StartCoroutine(TransicionMapa());
                player.transform.position = new Vector3(-4f, 14.5f, 0f);
                mover.MoverHacia(new Vector3(-6f, 19f, 0f));
                Camera.main.transform.position = new Vector3(0f, 17f, -10f);
                //Conversación + Mover enemigo
                if(pistaPapel && !llaveMansion){
                    sonidoManager.cambiarAudio(2);
                    gestionIU.activarDialogo(1);
                    enemigo2.GetComponent<enemigosMov>().MoverHacia(new Vector3(-4.25f, 17f, 0f));
                }             
                break;
            case 3:
                pistaPapel = true;
                buttonPista.SetActive(false);
                textoPista.text = "Hay una nota que dice:\n'Reunión en la biblioteca al atardecer'";
                botonAceptar.SetActive(false);
                //Desactivar pistas biblioteca y activar enemigos
                buttonPista5.SetActive(false);
                buttonPista6.SetActive(false);
                enemigo2.SetActive(true);
                boss.SetActive(true);                
                break;
            case 4:
                pistaFuente = true;
                buttonPista3.SetActive(false);
                textoPista.text = "Parecen runas arcanas. Al tocarlas un destello te ciega y tienes visiones de un ser terrorífico. \n(-1 Cordura)";
                botonAceptar.SetActive(false);
                //Flash            
                StartCoroutine(TransicionMapa());
                personaje.cordura -= 1;
                gestionIU.ActualizarValores();
                break;
            case 6:
                pistaDiario = true;
                buttonPista4.SetActive(false);
                textoPista.text = "Parece un libro de hechizos arcano. Podría ser útil.\n(+10 Fuerza)";
                personaje.fuerza += 10;
                botonAceptar.SetActive(false);
                gestionIU.ActualizarValores();
                break;
            case 16:
                pistaPuerta = true;
                buttonPuerta.SetActive(false);
                botonAceptar.SetActive(false);
                if (pistaFuente){
                    textoPista.text = "Ves las mismas runas de la fuente y decides no acercarte más.";
                }else{
                    panelTexto.SetActive(false);                    
                    StartCoroutine(TransicionMapa());
                    enemigo.transform.position = new Vector3(7.5f, -4.5f, 0f);
                    enemigo.GetComponent<enemigosMov>().MoverHacia(new Vector3(4f, -4f, 0f));
                    panelTexto.SetActive(true);
                    textoPista.text = "Ves algo correr hacia tí y te desestabilizas.\n(-1 Vida)";
                    personaje.vida -= 1;  
                    activarDialogo = true; 
                }
                gestionIU.ActualizarValores();
                break;
            case 17:
                panelTexto.SetActive(false);
                sonidoManager.cambiarAudio(1);
                //transportar hasta mapa pueblo
                StartCoroutine(TransicionMapa());
                player.transform.position = new Vector3(-1.5f, 4.5f, 0f);
                mover.MoverHacia(new Vector3(2.5f, 3f, 0f));
                Camera.main.transform.position = new Vector3(0f, 0f, -10f);
                break;
            case 7:
                pistaCocina = true;
                buttonPista5.SetActive(false);
                textoPista.text = "Después de acabártelo te encuentras mucho mejor.\n(+2 Vida)";
                personaje.vida += 2;
                botonAceptar.SetActive(false);
                gestionIU.ActualizarValores();
                break;
            case 8:
                pistaLibro = true;
                buttonPista6.SetActive(false);
                textoPista.text = "Resulta ser un libro de pociones y venenos.\n(+2 Cordura  +4 Conocimiento)";
                personaje.cordura += 2;
                personaje.conocimiento += 4;
                botonAceptar.SetActive(false);
                gestionIU.ActualizarValores();
                break;
            case 10:
                botonAceptar.SetActive(false);
                textoPista.text = "Me temo que no se puede abrir.\nSolo te queda una opción...";
                break;
        }
    }
    private IEnumerator TransicionMapa(){
        transicion.SetActive(true);
        fundidoMapa.SetTrigger("fundido");
        yield return new WaitForSeconds(fundidoMapa.GetCurrentAnimatorStateInfo(0).length);
        transicion.SetActive(false);
    }

    public void Cancelar(){
        botonAceptar.SetActive(true);
        panelTexto.SetActive(false);
        if(activarDialogo){
            gestionIU.activarDialogo(0);
            activarDialogo = false;
            enemigo.GetComponent<enemigosMov>().MoverHacia(new Vector3(-10f, 2f, 0f));
        }
    }

    public void combate(){
        StartCoroutine(TransicionMapa());
        gestionIU.Combate();
    }

    public void atacar(){
        cont++;
        var personaje = GameManager.instance.personajeActual;
        int tirada = Random.Range(1, 21);
        int resultado = personaje.fuerza + tirada;
        if(resultado>17){
            llaveMansion = true;
            //"-Tirada Válida-\nHas vencido a tu oponente";
            gestionIU.CombateOff();
            switch (cont){
                case 1:
                    enemigo2.SetActive(false);
                    boss.SetActive(false);
                    MostrarPista("Recoges del suelo un objeto que se le ha caído a tu oponente.\nHas encontrado 'Llave Mansión'", 100);
                    botonAceptar.SetActive(false);
                    break;
                case 2:
                    enemigo.SetActive(false);
                    break;
                case 3:
                    enemigo2.SetActive(false);
                    break;
                case 4:
                    enemigo3.SetActive(false);
                    gestionIU.partidaGanada();
                    break;
            }
        }else{
            gestionIU.gameOver();
        }
    }

    public void ResetearPistas(){
        llaveMansion = false;
        pistaFuente = false;
        pistaEstatuas = false;
        pistaEstatuas2 = false;
        activarDialogo = false;
        pistaDiario = false;
        pistaPuerta = false;
        pistaPapel = false;
        pistaCocina = false;
        pistaLibro = false;
        cont = 0;

        buttonPista.SetActive(true);
        buttonPista2.SetActive(true);
        buttonPista3.SetActive(true);
        buttonPista4.SetActive(true);
        buttonPista5.SetActive(true);
        buttonPista6.SetActive(true);
        buttonPuerta.SetActive(true);
        enemigo2.SetActive(false);
        boss.SetActive(false);
        enemigo2.transform.position = new Vector3(3f, 14.5f, 0f);
        boss.transform.position = new Vector3(5f, 14.5f, 0f);
    }

    public void RestaurarEstadoPistas(){
        if (pistaFuente) buttonPista3.SetActive(false);
        if (pistaPapel){
            buttonPista.SetActive(false);
            buttonPista5.SetActive(false);
            buttonPista6.SetActive(false);
            enemigo2.SetActive(true);
            boss.SetActive(true);
        } 
        if (pistaCocina) buttonPista5.SetActive(false);
        if (pistaLibro) buttonPista6.SetActive(false);
        if (pistaDiario) buttonPista4.SetActive(false);
        if (pistaEstatuas2) buttonPista2.SetActive(false);
        if (pistaPuerta) buttonPuerta.SetActive(false);
    }
}
