using UnityEngine;

[CreateAssetMenu(fileName = "NewPersonaje", menuName = "Personaje")]
public class Personajes : ScriptableObject
{
    public Sprite personaje;
    public Sprite imagen;
    public string nombre;
    public string desc;
    public int vida;
    public int cordura;
    public int fuerza;
    public int agilidad;
    public int conocimiento;
    public int observacion;
}
