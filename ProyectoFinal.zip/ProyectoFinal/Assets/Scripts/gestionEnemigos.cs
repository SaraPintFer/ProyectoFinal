using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class gestionEnemigos : MonoBehaviour
{
    public GameObject resaltado;
    public EventosManager eventosManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {  
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void OnMouseEnter(){
        resaltado.SetActive(true);
    }

    public void OnMouseExit(){
        resaltado.SetActive(false);
    }

    private void OnMouseDown(){
        eventosManager.combate();
    }
}
