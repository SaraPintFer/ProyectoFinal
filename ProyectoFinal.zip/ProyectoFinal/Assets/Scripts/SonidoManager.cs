using UnityEngine;

public class SonidoManager : MonoBehaviour
{
    [SerializeField] private AudioClip[] audios;

    private AudioSource controAudio;

    private void Awake(){
        controAudio = GetComponent<AudioSource>();
        controAudio.clip = audios[0];
        controAudio.Play();
    }

    public void cambiarAudio(int index){
        controAudio.clip = audios[index];
        controAudio.Play();
    }
}
