using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public List<Personajes> personajes;
    public List<Zonas> zonasDelJuego;
    public PersonajeActual personajeActual;
    public EventosManager eventosManager;

    private void Awake() {
        if(GameManager.instance == null){
            GameManager.instance = this;
            DontDestroyOnLoad(this.gameObject);
        }else{
            Destroy(gameObject);
        }
    }

    public void NuevaPartida() {
        foreach (Zonas zona in zonasDelJuego){
            zona.visitada = false;
            zona.tienePeligro = false;
        }
        eventosManager.ResetearPistas();
    }

    public void ConfirmarPersonaje(int index) {
        personajeActual = new PersonajeActual(personajes[index]);
    }
}