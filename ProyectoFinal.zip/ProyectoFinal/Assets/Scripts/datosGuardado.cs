using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class datosGuardado
{
    public int personajeIndex;
    public int vida;
    public int cordura;
    public int fuerza;
    public int agilidad;
    public int conocimiento;
    public int observacion;
    public Vector3 posicionJugador;
    public Vector3 posicionCamara;
    public Vector3 posicionEnemigo1;
    public Vector3 posicionEnemigo2;

    public bool llaveMansion;
    public bool pistaFuente;
    public bool pistaEstatuas;
    public bool pistaEstatuas2;
    public bool pistaPapel;
    public bool pistaPuerta;
    public bool pistaDiario;
    public bool pistaCocina;
    public bool pistaLibro;
    public int cont;

    public List<ZonaGuardada> zonasVisitadas = new List<ZonaGuardada>();
}

[System.Serializable]
public class ZonaGuardada
{
    public string nombreZona;
    public bool visitada;
    public bool requiereItem;
    public bool tienePeligro;
}