using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using UnityEditor;

public class gestionIU : MonoBehaviour
{
    [SerializeField] private GameObject seleccionPersona;
    [SerializeField] private GameObject ajustes;
    [SerializeField] private GameObject pausa;
    [SerializeField] private GameObject infoPersonaje;
    [SerializeField] private GameObject menuInicio;
    [SerializeField] private GameObject historia;
    [SerializeField] private GameObject transicion;
    [SerializeField] private GameObject panelTexto;
    [SerializeField] private GameObject panelGameOver;
    [SerializeField] private GameObject dialogo;
    [SerializeField] private GameObject combate;

    [SerializeField] private GameObject panelIntro;

    [SerializeField] private Animator fundido;

    [SerializeField] private Button botonContinuar;
    [SerializeField] private Button botonGuardar;
    [SerializeField] private Button ButtonInfo;

    private int cont;
    [SerializeField] private TextMeshProUGUI historia1;
    [SerializeField] private TextMeshProUGUI historia2;
    [SerializeField] private TextMeshProUGUI textDialogo;
    [SerializeField, TextArea] private string[] lineasDialogo;
    [SerializeField] private TextMeshProUGUI victoria;

    public int index;
    [SerializeField] private Image imagen;
    [SerializeField] private TextMeshProUGUI nombre;
    [SerializeField] private TextMeshProUGUI desc;
    [SerializeField] private TextMeshProUGUI vida;
    [SerializeField] private TextMeshProUGUI cordura;
    [SerializeField] private TextMeshProUGUI fuerza;
    [SerializeField] private TextMeshProUGUI agilidad;
    [SerializeField] private TextMeshProUGUI conocimiento;
    [SerializeField] private TextMeshProUGUI observacion;

    [SerializeField] private Image imagen2;
    [SerializeField] private TextMeshProUGUI nombre2;
    [SerializeField] private TextMeshProUGUI desc2;
    [SerializeField] private TextMeshProUGUI vida2;
    [SerializeField] private TextMeshProUGUI cordura2;
    [SerializeField] private TextMeshProUGUI fuerza2;
    [SerializeField] private TextMeshProUGUI agilidad2;
    [SerializeField] private TextMeshProUGUI conocimiento2;
    [SerializeField] private TextMeshProUGUI observacion2;

    [SerializeField] private TextMeshProUGUI vidaIU;
    [SerializeField] private TextMeshProUGUI corduraIU;
    [SerializeField] private Image imagenAtaque;

    [SerializeField] private Transform jugadorTransform;

    public SonidoManager sonidoManager;
    private GameManager gameManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
        gameManager = GameManager.instance;
        menuInicio.SetActive(true);
        seleccionPersona.SetActive(false);
        infoPersonaje.SetActive(false);
        pausa.SetActive(false);
        ajustes.SetActive(false);
        historia.SetActive(false);
        transicion.SetActive(false);
        panelTexto.SetActive(false);
        panelIntro.SetActive(false);
        panelGameOver.SetActive(false);
        dialogo.SetActive(false);
        combate.SetActive(false);
        cambiarPersona();

        botonContinuar.interactable = SaveManager.HayPartidaGuardada();
    }

    // Update is called once per frame
    void Update()
    {  
    }

    public void iniciar(){
        GameManager.instance.NuevaPartida();
        PlayerPrefs.DeleteAll();
        index= 0;
        cont=0;
        cambiarPersona();
        menuInicio.SetActive(false);
        panelGameOver.SetActive(false);
        pausa.SetActive(false);
        combate.SetActive(false);
        seleccionPersona.SetActive(true);
        Camera.main.transform.position = new Vector3(0f, 0f, -10f);
    }

    public void siguiente(){
        if(index == gameManager.personajes.Count - 1){
            index=0;
        }else{
            index +=1;
        }
        cambiarPersona();
        EventSystem.current.SetSelectedGameObject(null);
    }

    public void cambiarPersona(){
        imagen.sprite = gameManager.personajes[index].imagen;
        nombre.text = gameManager.personajes[index].nombre;
        desc.text = gameManager.personajes[index].desc;
        vida.text = gameManager.personajes[index].vida.ToString();
        cordura.text = gameManager.personajes[index].cordura.ToString();
        fuerza.text = gameManager.personajes[index].fuerza.ToString();
        agilidad.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento.text = gameManager.personajes[index].conocimiento.ToString();
        observacion.text = gameManager.personajes[index].observacion.ToString();

        imagen2.sprite = gameManager.personajes[index].imagen;
        nombre2.text = gameManager.personajes[index].nombre;
        desc2.text = gameManager.personajes[index].desc;
        vida2.text = gameManager.personajes[index].vida.ToString();
        cordura2.text = gameManager.personajes[index].cordura.ToString();
        fuerza2.text = gameManager.personajes[index].fuerza.ToString();
        agilidad2.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento2.text = gameManager.personajes[index].conocimiento.ToString();
        observacion2.text = gameManager.personajes[index].observacion.ToString();
    }

    public void empezar(){
        seleccionPersona.SetActive(false);
        GameManager.instance.ConfirmarPersonaje(index);
        jugadorTransform.position = new Vector3(7.5f, 0f, 0f); 
        ButtonInfo.GetComponent<Image>().sprite = gameManager.personajes[index].imagen;
        vidaIU.text = gameManager.personajes[index].vida.ToString();
        corduraIU.text = gameManager.personajes[index].cordura.ToString();
        jugadorTransform.GetComponent<Animator>().runtimeAnimatorController = gameManager.personajes[index].animatorController;
        imagenAtaque.sprite = gameManager.personajes[index].ataque;
        StartCoroutine(TransicionYEmpezar());
        sonidoManager.cambiarAudio(1);
    }

    private IEnumerator TransicionYEmpezar(){
        transicion.SetActive(true);
        historia.SetActive(true);
        fundido.SetTrigger("fundido");
        yield return new WaitForSeconds(fundido.GetCurrentAnimatorStateInfo(0).length);
        transicion.SetActive(false);
    }

    public void continuarHisotria(){
        if(cont==0){
            historia1.gameObject.SetActive(false);
            historia2.gameObject.SetActive(true);
            EventSystem.current.SetSelectedGameObject(null);
            cont++;
        }else{
            historia1.gameObject.SetActive(true);
            historia2.gameObject.SetActive(false);
            historia.SetActive(false);
        }
    }

    public void info(){
        infoPersonaje.SetActive(true);
    }

    public void pausar(){
        pausa.SetActive(true);
        botonGuardar.interactable = true;
        sonidoManager.cambiarAudio(0);
    }

    public void continuar(){
        pausa.SetActive(false);
        sonidoManager.cambiarAudio(1);
    }

    public void guardar(){
        GuardarPartida();
        botonGuardar.interactable = false;
    }

    public void ajuste(){
        ajustes.SetActive(true);
    }

    public void back(){
        infoPersonaje.SetActive(false);
        ajustes.SetActive(false);
    }

    public void salirMenu(){
        pausa.SetActive(false);
        panelGameOver.SetActive(false);
        combate.SetActive(false);
        menuInicio.SetActive(true);
        botonContinuar.interactable = SaveManager.HayPartidaGuardada();
    }

    public void continuarGuardado(){
        menuInicio.SetActive(false);
        sonidoManager.cambiarAudio(1);
        if (SaveManager.HayPartidaGuardada()){
            CargarPartida();
        }
    }

    public void salirJuego(){
        Application.Quit();
    }  

    public void ActualizarValores(){
        var personaje = GameManager.instance.personajeActual;
        vidaIU.text = personaje.vida.ToString();
        corduraIU.text = personaje.cordura.ToString();
        vida2.text = personaje.vida.ToString();
        cordura2.text = personaje.cordura.ToString();
        fuerza2.text = personaje.fuerza.ToString();
        agilidad2.text = personaje.agilidad.ToString();
        conocimiento2.text = personaje.conocimiento.ToString();
        observacion2.text = personaje.observacion.ToString();
    }

    public void gameOver(){
        panelGameOver.SetActive(true);
        sonidoManager.cambiarAudio(0);
    }

    public void partidaGanada(){
        panelGameOver.SetActive(true);
        victoria.text = "¡Has ganado!";
        sonidoManager.cambiarAudio(0);
    }

    public void activarDialogo(int num){
        dialogo.SetActive(true);
        StartCoroutine(tepeoDialogo(num));
    }
    private IEnumerator tepeoDialogo(int num){
        textDialogo.text = string.Empty;

        foreach(char letra in lineasDialogo[num]){
            textDialogo.text += letra;
            yield return new WaitForSeconds(0.05f);
        }
        yield return new WaitForSeconds(1f);
        dialogo.SetActive(false);
    }
    public void Combate(){
        combate.SetActive(true);
    }

    public void CombateOff(){
        combate.SetActive(false);
    }

    public void GuardarPartida(){
        var personaje = GameManager.instance.personajeActual;
        var zonas = GameManager.instance.zonasDelJuego;
        var eventos = GameManager.instance.eventosManager;

        datosGuardado datos = new datosGuardado{
            personajeIndex = index,
            vida = personaje.vida,
            cordura = personaje.cordura,
            fuerza = personaje.fuerza,
            agilidad = personaje.agilidad,
            conocimiento = personaje.conocimiento,
            observacion = personaje.observacion,

            posicionJugador = jugadorTransform.position,
            posicionCamara = Camera.main.transform.position,
            posicionEnemigo1 = eventos.enemigo.transform.position,
            posicionEnemigo2 = eventos.enemigo2.transform.position,

            llaveMansion = eventos.llaveMansion,
            pistaFuente = eventos.pistaFuente,
            pistaEstatuas = eventos.pistaEstatuas,
            pistaEstatuas2 = eventos.pistaEstatuas2,
            pistaPapel = eventos.pistaPapel,
            pistaPuerta = eventos.pistaPuerta,
            pistaDiario = eventos.pistaDiario,
            pistaCocina = eventos.pistaCocina,
            pistaLibro = eventos.pistaLibro,
            cont = eventos.cont,

            zonasVisitadas = new List<ZonaGuardada>(),
        };

        foreach (var zona in zonas){
            ZonaGuardada zg = new ZonaGuardada{
                nombreZona = zona.nombreZona,
                visitada = zona.visitada,
                requiereItem = zona.requiereItem,
                tienePeligro = zona.tienePeligro
            };
            datos.zonasVisitadas.Add(zg);
        }

        SaveManager.GuardarProgreso(datos);
    }

    public void CargarPartida(){
        datosGuardado datos = SaveManager.CargarProgreso();
        if (datos == null) return;

        index = datos.personajeIndex;
        GameManager.instance.ConfirmarPersonaje(index);

        var personaje = GameManager.instance.personajeActual;
        personaje.vida = datos.vida;
        personaje.cordura = datos.cordura;
        personaje.fuerza = datos.fuerza;
        personaje.agilidad = datos.agilidad;
        personaje.conocimiento = datos.conocimiento;
        personaje.observacion = datos.observacion;

        jugadorTransform.position = datos.posicionJugador;
        Camera.main.transform.position = datos.posicionCamara;

        var eventos = GameManager.instance.eventosManager;
        eventos.enemigo.transform.position = datos.posicionEnemigo1;
        eventos.enemigo2.transform.position = datos.posicionEnemigo2;

        eventos.llaveMansion = datos.llaveMansion;
        eventos.pistaFuente = datos.pistaFuente;
        eventos.pistaEstatuas = datos.pistaEstatuas;
        eventos.pistaEstatuas2 = datos.pistaEstatuas2;
        eventos.pistaPapel = datos.pistaPapel;
        eventos.pistaPuerta = datos.pistaPuerta;
        eventos.pistaDiario = datos.pistaDiario;
        eventos.pistaCocina = datos.pistaCocina;
        eventos.pistaLibro = datos.pistaLibro;
        eventos.cont = datos.cont;

        for (int i = 0; i < GameManager.instance.zonasDelJuego.Count; i++){
            var zonaGuardada = datos.zonasVisitadas[i];
            var zonaJuego = GameManager.instance.zonasDelJuego[i];

            zonaJuego.visitada = zonaGuardada.visitada;
            zonaJuego.requiereItem = zonaGuardada.requiereItem;
            zonaJuego.tienePeligro = zonaGuardada.tienePeligro;
        }
        cambiarPersona();
        ButtonInfo.GetComponent<Image>().sprite = gameManager.personajes[index].imagen;
        jugadorTransform.GetComponent<Animator>().runtimeAnimatorController = gameManager.personajes[index].animatorController;
        imagenAtaque.sprite = gameManager.personajes[index].ataque;
        ActualizarValores();
        GameManager.instance.eventosManager.RestaurarEstadoPistas();
    }
}
