using UnityEngine;
using UnityEngine.EventSystems;

public class zonaMapa : MonoBehaviour
{
    public Vector3 centroZona;
    private SpriteRenderer sr;
    private Collider2D col;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        col = GetComponent<Collider2D>();
        sr = GetComponent<SpriteRenderer>();

        if (centroZona == Vector3.zero)
        {
            centroZona = col.bounds.center;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()){
            //Si el ratón está sobre un UI salir del método para no afectar al mapa
            Color c = sr.color;
            c.a = 0f;
            sr.color = c;
            return;
        }
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 mouse2D = new Vector2(mouseWorldPos.x, mouseWorldPos.y);

        if (col.OverlapPoint(mouse2D))
        {
            if (sr != null){
                Color c = sr.color;
                c.a = 0.15f;
                sr.color = c;
            }

            if (Input.GetMouseButtonDown(0))
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player != null)
                {
                    player.transform.position = new Vector3(centroZona.x, centroZona.y, player.transform.position.z);
                }
            }
        }
        else
        {
            if (sr != null){
                Color c = sr.color;
                c.a = 0f;
                sr.color = c;
            }
        }
    }
}
