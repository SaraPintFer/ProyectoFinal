using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class zonaMapa : MonoBehaviour
{
    public Vector3 centroZona;
    private SpriteRenderer sr;
    private Collider2D col2D;

    public Zonas datoZona;
    public List<GameObject> zonasVecinas;

    public EventosManager eventosManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        col2D = GetComponent<Collider2D>();
        sr = GetComponent<SpriteRenderer>();

        if (centroZona == Vector3.zero){
            centroZona = col2D.bounds.center;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()){
            //Si el ratón está sobre un UI salir del método para no afectar al mapa
            Color c = sr.color;
            c.a = 0f;
            sr.color = c;
            return;
        }
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 mouse2D = new Vector2(mouseWorldPos.x, mouseWorldPos.y);

        if (col2D.OverlapPoint(mouse2D)){
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            //"Enviar" orden de movimiento
            jugadorMov mover = player.GetComponent<jugadorMov>();

            if (mover != null && mover.zonaActual != null){
                zonaMapa zonaActual = mover.zonaActual.GetComponent<zonaMapa>();
                
                if (zonaActual != null && zonaActual.zonasVecinas.Contains(gameObject)){
                    Color c = sr.color;
                    c.a = 0.15f;
                    sr.color = c;
                    if (Input.GetMouseButtonDown(0)){
                        mover.MoverHacia(centroZona);
                        
                        if(!datoZona.visitada){
                            eventosManager.MostrarNarrativa(datoZona.descripcionNarrativa);
                            datoZona.visitada = true;
                        }
                    }
                }
            }
        }
        else{
            Color c = sr.color;
            c.a = 0f;
            sr.color = c;
        }
    }
}
