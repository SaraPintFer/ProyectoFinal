using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class SaveManager
{
    private static string rutaArchivo => Application.persistentDataPath + "/partida.json";
    
    public static void GuardarProgreso(datosGuardado datos){
        string json = JsonUtility.ToJson(datos, true);
        File.WriteAllText(rutaArchivo, json);
        Debug.Log("Partida guardada en " + rutaArchivo);
    }

    public static datosGuardado CargarProgreso(){
        if (File.Exists(rutaArchivo)){
            string json = File.ReadAllText(rutaArchivo);
            return JsonUtility.FromJson<datosGuardado>(json);
        } else{
            Debug.LogWarning("No se encontró archivo de guardado.");
            return null;
        }
    }

    public static bool HayPartidaGuardada(){
        return File.Exists(rutaArchivo);
    }
}
