using UnityEngine;

[CreateAssetMenu(fileName = "NewZona", menuName = "Zona")]
public class Zonas : ScriptableObject
{
    public int idZona;
    public string nombreZona;
    [TextArea] public string descripcionNarrativa;

    public bool tienePista;
    [TextArea] public string textoPista;

    public bool tienePuerta;
    [TextArea] public string textoPuerta;

    public bool bloqueaPaso; //Por si hay zonas con restricción de acceso
    public bool requiereItem;
    public string nombreItemRequerido;
    [HideInInspector] public bool tienePeligro = false;
    [HideInInspector] public bool visitada = false;
}
