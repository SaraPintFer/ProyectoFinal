using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using UnityEditor;

public class gestionIU : MonoBehaviour
{
    [SerializeField] private GameObject seleccionPersona;
    [SerializeField] private GameObject ajustes;
    [SerializeField] private GameObject pausa;
    [SerializeField] private GameObject infoPersonaje;
    [SerializeField] private GameObject menuInicio;

    [SerializeField] private Button ButtonInfo;
    [SerializeField] private SpriteRenderer SpriteJugador;

    private int index;
    [SerializeField] private Image imagen;
    [SerializeField] private TextMeshProUGUI nombre;
    [SerializeField] private TextMeshProUGUI desc;
    [SerializeField] private TextMeshProUGUI vida;
    [SerializeField] private TextMeshProUGUI cordura;
    [SerializeField] private TextMeshProUGUI fuerza;
    [SerializeField] private TextMeshProUGUI agilidad;
    [SerializeField] private TextMeshProUGUI conocimiento;
    [SerializeField] private TextMeshProUGUI observacion;

    [SerializeField] private Image imagen2;
    [SerializeField] private TextMeshProUGUI nombre2;
    [SerializeField] private TextMeshProUGUI desc2;
    [SerializeField] private TextMeshProUGUI vida2;
    [SerializeField] private TextMeshProUGUI cordura2;
    [SerializeField] private TextMeshProUGUI fuerza2;
    [SerializeField] private TextMeshProUGUI agilidad2;
    [SerializeField] private TextMeshProUGUI conocimiento2;
    [SerializeField] private TextMeshProUGUI observacion2;

    private GameManager gameManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
        gameManager = GameManager.instance;

        index= PlayerPrefs.GetInt("indexPersona");
        cambiarPersona();
    }

    // Update is called once per frame
    void Update()
    {  
    }

    private void cambiarPersona(){
        PlayerPrefs.SetInt("indexPersona", index);
        imagen.sprite = gameManager.personajes[index].imagen;
        nombre.text = gameManager.personajes[index].nombre;
        desc.text = gameManager.personajes[index].desc;
        vida.text = gameManager.personajes[index].vida.ToString();
        cordura.text = gameManager.personajes[index].cordura.ToString();
        fuerza.text = gameManager.personajes[index].fuerza.ToString();
        agilidad.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento.text = gameManager.personajes[index].conocimiento.ToString();
        observacion.text = gameManager.personajes[index].observacion.ToString();
    }

    public void siguiente(){
        if(index == gameManager.personajes.Count - 1){
            index=0;
        }else{
            index +=1;
        }
        cambiarPersona();
        EventSystem.current.SetSelectedGameObject(null);
    }

    public void start(){
        seleccionPersona.SetActive(false);
        ButtonInfo.GetComponent<Image>().sprite = gameManager.personajes[index].imagen;
        SpriteJugador.sprite = gameManager.personajes[index].personaje;
        Debug.Log("Sprite cargado: " + gameManager.personajes[index].personaje.name);
    }

    public void pausar(){
        pausa.SetActive(true);

    }
    public void iniciar(){
        menuInicio.SetActive(false);
        seleccionPersona.SetActive(true);
    }

    public void continuar(){
        pausa.SetActive(false);
    }

    public void ajuste(){
        ajustes.SetActive(true);
    }

    public void info(){
        infoPersonaje.SetActive(true);

        imagen2.sprite = gameManager.personajes[index].imagen;
        nombre2.text = gameManager.personajes[index].nombre;
        desc2.text = gameManager.personajes[index].desc;
        vida2.text = gameManager.personajes[index].vida.ToString();
        cordura2.text = gameManager.personajes[index].cordura.ToString();
        fuerza2.text = gameManager.personajes[index].fuerza.ToString();
        agilidad2.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento2.text = gameManager.personajes[index].conocimiento.ToString();
        observacion2.text = gameManager.personajes[index].observacion.ToString();
    }

    public void back(){
        infoPersonaje.SetActive(false);
        ajustes.SetActive(false);
    }

    public void salirMenu(){
        ajustes.SetActive(false);
        pausa.SetActive(false);
        menuInicio.SetActive(true);
    }

    public void salirJuego(){
        EditorApplication.isPlaying = false;
        //Application.Quit();
    }
}
