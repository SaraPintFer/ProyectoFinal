using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class enemigosMov : MonoBehaviour
{
    public float velocidad = 3f;
    private Vector3 destino;
    private bool enMovimiento = false;
    private Animator anim;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        anim = GetComponent<Animator>();
        Collider2D col = Physics2D.OverlapPoint(transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, Vector3.up, Color.red);

        if (enMovimiento){
            transform.position = Vector3.MoveTowards(transform.position, destino, velocidad * Time.deltaTime);
            anim.SetBool("isMoviendo", true);

            if (Vector3.Distance(transform.position, destino) < 0.05f){
                transform.position = destino;
                enMovimiento = false;
                anim.SetBool("isMoviendo", false);
            }
        }
    }

    public void MoverHacia(Vector3 nuevaPosicion)
    {
        destino = new Vector3(nuevaPosicion.x, nuevaPosicion.y, transform.position.z); // Mantiene Z
        enMovimiento = true;
    }
}
