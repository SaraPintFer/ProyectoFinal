using UnityEngine;

[System.Serializable]
public class datosGuardado
{
    public int personajeIndex;
    public float vida;
    public float cordura;
    public float[] posicion;
}
