using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using UnityEditor;

public class gestionIU : MonoBehaviour
{
    [SerializeField] private GameObject seleccionPersona;
    [SerializeField] private GameObject ajustes;
    [SerializeField] private GameObject pausa;
    [SerializeField] private GameObject infoPersonaje;
    [SerializeField] private GameObject menuInicio;
    [SerializeField] private GameObject historia;
    [SerializeField] private GameObject transicion;

    [SerializeField] private Animator fundido;

    [SerializeField] private Button botonContinuar;
    [SerializeField] private Button botonGuardar;
    [SerializeField] private Button ButtonInfo;

    private int cont;
    [SerializeField] private TextMeshProUGUI historia1;
    [SerializeField] private TextMeshProUGUI historia2;
    private int index;
    [SerializeField] private Image imagen;
    [SerializeField] private TextMeshProUGUI nombre;
    [SerializeField] private TextMeshProUGUI desc;
    [SerializeField] private TextMeshProUGUI vida;
    [SerializeField] private TextMeshProUGUI cordura;
    [SerializeField] private TextMeshProUGUI fuerza;
    [SerializeField] private TextMeshProUGUI agilidad;
    [SerializeField] private TextMeshProUGUI conocimiento;
    [SerializeField] private TextMeshProUGUI observacion;

    [SerializeField] private Image imagen2;
    [SerializeField] private TextMeshProUGUI nombre2;
    [SerializeField] private TextMeshProUGUI desc2;
    [SerializeField] private TextMeshProUGUI vida2;
    [SerializeField] private TextMeshProUGUI cordura2;
    [SerializeField] private TextMeshProUGUI fuerza2;
    [SerializeField] private TextMeshProUGUI agilidad2;
    [SerializeField] private TextMeshProUGUI conocimiento2;
    [SerializeField] private TextMeshProUGUI observacion2;

    [SerializeField] private TextMeshProUGUI vidaIU;
    [SerializeField] private TextMeshProUGUI corduraIU;

    [SerializeField] private Transform jugadorTransform;

    private GameManager gameManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
        gameManager = GameManager.instance;
        menuInicio.SetActive(true);
        seleccionPersona.SetActive(false);
        infoPersonaje.SetActive(false);
        pausa.SetActive(false);
        ajustes.SetActive(false);
        historia.SetActive(false);
        transicion.SetActive(false);
        index= 0;
        cont=0;
        cambiarPersona();

        botonContinuar.interactable = SaveManager.HayPartidaGuardada();
    }

    // Update is called once per frame
    void Update()
    {  
    }

    public void iniciar(){
        PlayerPrefs.DeleteAll();
        index= 0;
        cont=0;
        cambiarPersona();
        menuInicio.SetActive(false);
        seleccionPersona.SetActive(true);
    }

    public void siguiente(){
        if(index == gameManager.personajes.Count - 1){
            index=0;
        }else{
            index +=1;
        }
        cambiarPersona();
        EventSystem.current.SetSelectedGameObject(null);
    }

    private void cambiarPersona(){
        imagen.sprite = gameManager.personajes[index].imagen;
        nombre.text = gameManager.personajes[index].nombre;
        desc.text = gameManager.personajes[index].desc;
        vida.text = gameManager.personajes[index].vida.ToString();
        cordura.text = gameManager.personajes[index].cordura.ToString();
        fuerza.text = gameManager.personajes[index].fuerza.ToString();
        agilidad.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento.text = gameManager.personajes[index].conocimiento.ToString();
        observacion.text = gameManager.personajes[index].observacion.ToString();

        imagen2.sprite = gameManager.personajes[index].imagen;
        nombre2.text = gameManager.personajes[index].nombre;
        desc2.text = gameManager.personajes[index].desc;
        vida2.text = gameManager.personajes[index].vida.ToString();
        cordura2.text = gameManager.personajes[index].cordura.ToString();
        fuerza2.text = gameManager.personajes[index].fuerza.ToString();
        agilidad2.text = gameManager.personajes[index].agilidad.ToString();
        conocimiento2.text = gameManager.personajes[index].conocimiento.ToString();
        observacion2.text = gameManager.personajes[index].observacion.ToString();
    }

    public void empezar(){
        seleccionPersona.SetActive(false);
        jugadorTransform.position = new Vector3(7.5f, 0f, 0f); 
        ButtonInfo.GetComponent<Image>().sprite = gameManager.personajes[index].imagen;
        vidaIU.text = gameManager.personajes[index].vida.ToString();
        corduraIU.text = gameManager.personajes[index].cordura.ToString();
        jugadorTransform.GetComponent<Animator>().runtimeAnimatorController = gameManager.personajes[index].animatorController;
        StartCoroutine(TransicionYEmpezar());
    }

    private IEnumerator TransicionYEmpezar(){
        transicion.SetActive(true);
        historia.SetActive(true);
        fundido.SetTrigger("fundido");
        yield return new WaitForSeconds(fundido.GetCurrentAnimatorStateInfo(0).length);
        transicion.SetActive(false);
    }

    public void continuarHisotria(){
        if(cont==0){
            historia1.gameObject.SetActive(false);
            historia2.gameObject.SetActive(true);
            EventSystem.current.SetSelectedGameObject(null);
            cont++;
        }else{
            historia1.gameObject.SetActive(true);
            historia2.gameObject.SetActive(false);
            historia.SetActive(false);
        }
    }

    public void info(){
        infoPersonaje.SetActive(true);
    }

    public void pausar(){
        pausa.SetActive(true);
        botonGuardar.interactable = true;
    }

    public void continuar(){
        menuInicio.SetActive(false);
        pausa.SetActive(false);

        if (SaveManager.HayPartidaGuardada()){
            index = SaveManager.CargarIndex();
            cambiarPersona();
            jugadorTransform.position = SaveManager.CargarPosicion();
        }
    }

    public void guardar(){
        SaveManager.GuardarProgreso(jugadorTransform.position, index);
        botonGuardar.interactable = false;
    }

    public void ajuste(){
        ajustes.SetActive(true);
    }

    public void back(){
        infoPersonaje.SetActive(false);
        ajustes.SetActive(false);
    }

    public void salirMenu(){
        pausa.SetActive(false);
        menuInicio.SetActive(true);
        botonContinuar.interactable = SaveManager.HayPartidaGuardada();
    }

    public void salirJuego(){
        EditorApplication.isPlaying = false;
        //Application.Quit();
    }  
}
