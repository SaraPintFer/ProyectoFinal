using UnityEngine;

[CreateAssetMenu(fileName = "NewPersonaje", menuName = "Personaje")]
public class Personajes : ScriptableObject
{
    public Sprite imagen;
    public RuntimeAnimatorController animatorController;
    public string nombre;
    public string desc;
    public int vida;
    public int cordura;
    public int fuerza;
    public int agilidad;
    public int conocimiento;
    public int observacion;
}
