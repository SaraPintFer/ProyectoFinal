using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class jugadorMov : MonoBehaviour
{
    public float velocidad = 5f;
    private Vector3 destino;
    private bool enMovimiento = false;
    private Animator anim;

    [HideInInspector]
    public GameObject zonaActual;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        anim = GetComponent<Animator>();

        Collider2D col = Physics2D.OverlapPoint(transform.position);
        if (col != null && col.CompareTag("Zona")){
            zonaActual = col.gameObject;
        }
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, Vector3.up, Color.red);

        if (enMovimiento)
        {
            transform.position = Vector3.MoveTowards(transform.position, destino, velocidad * Time.deltaTime);
            anim.SetBool("isMoviendo", true);

            if (Vector3.Distance(transform.position, destino) < 0.05f)
            {
                transform.position = destino;
                enMovimiento = false;
                anim.SetBool("isMoviendo", false);
            }
        }
    }

    public void MoverHacia(Vector3 nuevaPosicion)
    {
        destino = new Vector3(nuevaPosicion.x, nuevaPosicion.y, transform.position.z); // Mantiene Z
        enMovimiento = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Zona")){
            zonaActual = other.gameObject;
        }
    }
}
