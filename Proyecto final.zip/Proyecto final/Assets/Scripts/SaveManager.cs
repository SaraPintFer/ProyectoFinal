using UnityEngine;

public class SaveManager
{
    public static void GuardarProgreso(Vector3 posicion, int index){
        PlayerPrefs.SetFloat("posX", posicion.x);
        PlayerPrefs.SetFloat("posY", posicion.y);
        PlayerPrefs.SetFloat("posZ", posicion.z);
        PlayerPrefs.SetInt("indexPersona", index);
        PlayerPrefs.SetInt("partidaGuardada", 1);
        PlayerPrefs.Save();
    }

    public static Vector3 CargarPosicion(){
        float x = PlayerPrefs.GetFloat("posX", 0);
        float y = PlayerPrefs.GetFloat("posY", 0);
        float z = PlayerPrefs.GetFloat("posZ", 0);
        return new Vector3(x, y, z);
    }

    public static int CargarIndex(){
        return PlayerPrefs.GetInt("indexPersona", 0);
    }

    public static bool HayPartidaGuardada(){
        return PlayerPrefs.HasKey("partidaGuardada") && PlayerPrefs.GetInt("partidaGuardada") == 1;
    }
}
