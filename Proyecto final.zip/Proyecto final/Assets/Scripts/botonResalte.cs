using UnityEngine;
using UnityEngine.EventSystems;

public class botonResalte : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject resaltado;
    public GameObject panelTexto;
    public GameObject zonaAsociada;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {  
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void OnPointerEnter(PointerEventData eventData){
        GameObject jugador = GameObject.FindGameObjectWithTag("Player");
        if (zonaAsociada.GetComponent<Collider2D>().OverlapPoint(jugador.transform.position)){
            resaltado.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData){
        resaltado.SetActive(false);
    }

    public void MostrarVentana(){
        GameObject jugador = GameObject.FindGameObjectWithTag("Player");
        if (zonaAsociada.GetComponent<Collider2D>().OverlapPoint(jugador.transform.position)){
            panelTexto.SetActive(true);
        }
    }
}
